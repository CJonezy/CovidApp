# covid-app
Covid-19 software application supporting contact tracing, vaccine rollout &amp; certification, alerting and general reports.
